import { HttpService } from '@nestjs/common';
export declare class CharacterService {
    private httpService;
    constructor(httpService: HttpService);
    findCharactersByName({ name }: {
        name: any;
    }): Promise<any>;
}
