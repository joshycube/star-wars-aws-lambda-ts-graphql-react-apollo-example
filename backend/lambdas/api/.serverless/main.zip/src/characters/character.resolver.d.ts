import { CharacterArgs } from './dto/character.args';
import { Character } from './models/character.model';
import { CharacterService } from './character.service';
export declare class CharacterResolver {
    private readonly characterService;
    constructor(characterService: CharacterService);
    character(characterArgs: CharacterArgs): Promise<Character[]>;
}
