export declare class Character {
    id: string;
    name: string;
    mass: number;
    height: number;
}
