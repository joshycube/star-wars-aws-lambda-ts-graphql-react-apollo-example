export declare class CharacterArgs {
    name: string;
}
