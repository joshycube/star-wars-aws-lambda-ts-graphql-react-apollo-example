export declare class CharacterModule {
}
