"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CharacterService = void 0;
const common_1 = require("@nestjs/common");
let CharacterService = class CharacterService {
    constructor(httpService) {
        this.httpService = httpService;
    }
    async findCharactersByName({ name }) {
        var _a, _b, _c;
        try {
            const response = this.httpService.get(`https://swapi.dev/api/people/?search=${name}`);
            const responesPromise = await response.toPromise();
            if (!!((_b = (_a = responesPromise === null || responesPromise === void 0 ? void 0 : responesPromise.data) === null || _a === void 0 ? void 0 : _a.results) === null || _b === void 0 ? void 0 : _b.length)) {
                const results = (_c = responesPromise === null || responesPromise === void 0 ? void 0 : responesPromise.data) === null || _c === void 0 ? void 0 : _c.results;
                return results.map((result) => ({
                    id: result.url,
                    name: result.name,
                    mass: result.mass === 'unknown' ? 0 : result.mass,
                    height: result.height,
                }));
            }
            else {
                throw new common_1.NotFoundException(name);
            }
        }
        catch (error) {
            throw error;
        }
    }
};
CharacterService = __decorate([
    common_1.Injectable(),
    __metadata("design:paramtypes", [common_1.HttpService])
], CharacterService);
exports.CharacterService = CharacterService;
//# sourceMappingURL=character.service.js.map